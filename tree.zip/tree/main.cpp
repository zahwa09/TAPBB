
#include "tree.hpp"

int main()
{
    BinTree T=Nil;
    //printf("Is TreeEmpty(T)=%s\n",TreeEmpty(T)?"true":"false");
    //printf("Is One Element(T)=%s\n",IsOneElement(T)?"true":"false");
    InsertNode(&T,45);
    //printf("Is One Element(T)=%s\n",IsOneElement(T)?"true":"false");
    //printf("Is Uner Left(T)=%s\n",IsUnerLeft(T)?"true":"false");
    InsertNode(&T,15);
    //printf("Is One Element(T)=%s\n",IsOneElement(T)?"true":"false");
    //printf("Is Uner Left(T)=%s\n",IsUnerLeft(T)?"true":"false");
    InsertNode(&T,59);
    InsertNode(&T,50);
    InsertNode(&T,57);
    InsertNode(&T,75);
    printf("\nPrintInOrder : ");PrintInOrder(T);

    printf("\nPrintPreOrder : ");PrintPreOrder(T);
    printf("\nPrintPostOrder : ");PrintPostOrder(T);

    //printf("\nPrintPreOrder : ");PrintPreOrder(T);
    //printf("\nPrintPostOrder : ");PrintPostOrder(T);
    cout<< "\n\nJumlah Node Tree = "<<NbElmt(T)<<endl;
    cout<< "\nJumlah Daun = "<<NbDaun(T)<<endl;
    cout<< "\nJumlah NbDuaAnak = "<<NbDuaAnak(T)<<endl;
    // cout<< "\nJumlah Nbkanansaja = "<<Nbkanansaja(T)<<endl;
    // cout<< "\nJumlah NbDuaAnak = "<<NbDuaAnak(T)<<endl;

    return 0;
}

