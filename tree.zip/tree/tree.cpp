#include "tree.hpp"
bool TreeEmpty(BinTree T){
	return T==Nil;
}
BinTree Alokasi(infotype X) {
	BinTree baru;

    baru = (BinTree)malloc(sizeof(Node));
	if(baru != Nil) {
		Info(baru) = X;
		Left(baru) = Nil;
		Right(baru) = Nil;
	}
	return baru;
}

BinTree Tree(infotype Akar, BinTree L, BinTree R) {
    BinTree P;

    P = Alokasi(Akar);
    if(P!=Nil) {
        Left(P) = L;
        Right(P) = R;
    }
    return P;
}

void InsertNode(BinTree *T,infotype X){
    BinTree P=(*T);//address bantu
    if(TreeEmpty(P)){//kosong
        (*T)=Alokasi(X);
    }else{//isi
        if(X<= Info(P)){
            InsertNode(&(Left(P)), X);;
        }else{
            InsertNode(&(Right(P)), X);
        }
    }
}

void PrintInOrder(BinTree P) {
    if(TreeEmpty(P))
        return;
    else {
        PrintInOrder(Left(P));
        printf("%d ", Info(P));
        PrintInOrder(Right(P));
    }
}

void PrintPreOrder(BinTree P) {
    if(TreeEmpty(P))
        return;
    else {
        printf("%d ", Info(P));
        PrintPreOrder(Left(P));
        PrintPreOrder(Right(P));
    }
}

void PrintPostOrder(BinTree P) {
    if(TreeEmpty(P))
        return;
    else {

        PrintPostOrder(Left(P));
        PrintPostOrder(Right(P));
        printf("%d ", Info(P));
    }
}

bool IsOneElement(BinTree P){
    return (!TreeEmpty(P) && Left(P)==Nil && Right(P)==Nil);
}

bool IsUnerRight (BinTree P){
    return (!TreeEmpty(P) && Left(P)==Nil && Right(P)!=Nil);
}
bool IsUnerLeft (BinTree P){
    return (!TreeEmpty(P) && Left(P)!=Nil && Right(P)==Nil);
}
bool IsBiner (BinTree P){
    return (!TreeEmpty(P) && Left(P)!=Nil && Right(P)!=Nil);
}
int NbElmt(BinTree P){
    if(TreeEmpty(P)){
        return 0;
    }else
        return (1 + NbElmt(Left(P)) + NbElmt(Right(P)));
}

int Nbkanansaja(BinTree P){
    if(TreeEmpty(P)){
        return 0;
    }else if (IsUnerRight(P)){
        return (1 + Nbkanansaja(Left(P))+Nbkanansaja(Right(P)));
    }else{
        return (0 + Nbkanansaja(Left(P))+Nbkanansaja(Right(P)));
    }
}
int Nbkirisaja(BinTree P){
    if(TreeEmpty(P)){
        return 0;
    }else if (IsUnerLeft(P)){
        return (1 + Nbkirisaja(Left(P))+Nbkirisaja(Right(P)));
    }else{
        return (0 + Nbkirisaja(Left(P))+Nbkirisaja(Right(P)));
    }
}


int NbDaun(BinTree P){
    if(IsOneElement(P)) {
        return 1;
    }else{
        if(IsUnerLeft(P)){
            return NbDaun(Left(P));
        }else if(IsUnerRight(P)){
            return NbDaun(Right(P));
        }else{
            return NbDaun(Left(P))+NbDaun(Right(P));
        }
    }
}

int NbDuaAnak(BinTree P){
    if(IsBiner(P)) {
        return 1;
    }else{
        if(IsUnerLeft(P)){
            return NbDaun(Left(P));
        }else if(IsUnerRight(P)){
            return NbDaun(Right(P));
        }else{
            return NbDaun(Left(P))+NbDaun(Right(P));
        }
    }
}
