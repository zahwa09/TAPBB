#ifndef TREE_HPP_INCLUDED
#define TREE_HPP_INCLUDED
#include <stdio.h>
#include <iostream>
using namespace std;
#define Nil NULL
typedef int infotype;
typedef struct Node *address;
typedef struct Node {
	infotype Info;
	address Left;
	address Right;
};
typedef address BinTree;//untuk tahu root
BinTree Alokasi(infotype X);
void Dealokasi(BinTree *P);
BinTree Tree(infotype Akar, BinTree L, BinTree R);
bool TreeEmpty(BinTree P);
void InsertNode(BinTree *T,infotype X);
void PrintInOrder(BinTree T);
int NbElmt(BinTree P);
void PrintPreOrder(BinTree P);
void PrintPostOrder(BinTree P);
bool IsOneElement(BinTree P);
bool IsUnerLeft(BinTree P);
bool IsUnerRight(BinTree P);
bool IsBiner(BinTree P);
int NbDaun(BinTree P);
int NbDuaAnak(BinTree P);
int Nbkanansaja(BinTree P);
int Nbkirisaja(BinTree P);
//definisi selector
#define Info(P) (P)->Info
#define Left(P) (P)->Left
#define Right(P) (P)->Right

#endif // TREE_HPP_INCLUDED

